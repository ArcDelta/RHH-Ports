These banks were built with FMOD Studio.

The project file that built these ones will be made public in the near future, but are not part of this repository.
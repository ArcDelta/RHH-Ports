These inputs are from [Kenney's Input Prompts](https://kenney.nl/assets/input-prompts) and released under Creative Commons CC0.

Due to time constraints, I'm only including the default button prompts for each controller. In an ideal world, with proper controller bindings, it would include all prompts and map to them gracefully. 
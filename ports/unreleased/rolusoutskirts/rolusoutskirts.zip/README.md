## Installation
Download the demo from Steam: https://store.steampowered.com/app/3008890/Rolus_in_the_Outskirts and add the data to `rolusoutskirts/assets`.

## Default Gameplay Controls
| Button            | Action |
|--                 |--|
| START             |Menu|
| SELECT            |Crystal Power|
| D-PAD / JOYSTICK  |Move|
| A                 |Interact|
| B                 |Shoot|
| Y                 |Use item|

## Thanks
Penguins at Work -- The game  
JohnnyOnFlame -- GMLoader-Next  
PortMaster -- Testers & Devs  
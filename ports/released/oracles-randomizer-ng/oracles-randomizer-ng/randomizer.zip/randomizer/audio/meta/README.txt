This folder is of no relevance to the disassembly itself; it simply provides
information regarding available music tracks to oracles-randomizer-ng and the
webui.
